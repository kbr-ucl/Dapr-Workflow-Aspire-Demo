﻿namespace CrossCut.Messages.Ping;

public class PingCommand;