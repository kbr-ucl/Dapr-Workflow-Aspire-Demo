﻿namespace CrossCut.Messages.Ping;

public class PingResponse
{
    public required string Message { get; set; }
}