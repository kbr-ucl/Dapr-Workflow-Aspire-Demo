﻿using Microsoft.AspNetCore.Mvc;

namespace DaprWorkflowAspireDemo.Order.Api.Controllers;

[Route("api/[controller]")]
[ApiController]
public class OrderController : ControllerBase
{
}